package viewsModule;

import resultModule.Result;

public abstract interface View {
    public void draw(Result result);
}
